import json
import boto3
import urllib.parse
import uuid
from datetime import datetime

s3 = boto3.client('s3')
securityhub = boto3.client('securityhub')

def lambda_handler(event, context):
    region = context.invoked_function_arn.split(":")[3]
    account_id = context.invoked_function_arn.split(":")[4]

    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = urllib.parse.unquote_plus(record['s3']['object']['key'])
        print(f"[+] Processing {key} from {bucket}")

        try:
            # 1. S3에서 ZAP JSON 가져오기
            obj = s3.get_object(Bucket=bucket, Key=key)
            zap_data = json.loads(obj['Body'].read().decode('utf-8'))

            findings = []

            for site in zap_data.get('site', []):
                for alert in site.get('alerts', []):
                    title = alert.get('alert', 'ZAP Alert')
                    desc = alert.get('desc', '')
                    severity_raw = alert.get('riskdesc', '').split(' ')[0].upper()
                    url = alert.get('instances', [{}])[0].get('uri', 'unknown')

                    severity = severity_raw if severity_raw in ["LOW", "MEDIUM", "HIGH", "CRITICAL"] else "INFORMATIONAL"

                    finding = {
                        "SchemaVersion": "2018-10-08",
                        "Id": str(uuid.uuid4()),
                        "ProductArn": f"arn:aws:securityhub:{region}:{account_id}:product/{account_id}/default",
                        "AwsAccountId": account_id,
                        "GeneratorId": "zap-lambda",
                        "Title": f"[ZAP] {title}",
                        "Description": desc,
                        "Severity": { "Label": severity },
                        "Types": ["Software and Configuration Checks/Vulnerabilities"],
                        "CreatedAt": datetime.utcnow().isoformat() + "Z",
                        "UpdatedAt": datetime.utcnow().isoformat() + "Z",
                        "Resources": [{
                            "Type": "Other",
                            "Id": url
                        }]
                    }

                    findings.append(finding)

            # 2. 일부 내용 로그 출력 (확인용)
            if findings:
                print(f"[DEBUG] Example finding:\n{json.dumps(findings[0], indent=2)}")
                response = securityhub.batch_import_findings(Findings=findings)
                print(f"[+] 전송 완료: {len(findings)}개 findings 업로드")
            else:
                print("⚠️ 보낼 findings 없음.")

        except Exception as e:
            print(f"❌ 오류 발생: {e}")
