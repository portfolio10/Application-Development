import json
import boto3
import os
import urllib.parse
import urllib3

s3 = boto3.client('s3')
http = urllib3.PoolManager()

def lambda_handler(event, context):
    webhook_url = os.environ.get('SLACK_SONAR_WEBHOOK')
    target_rules_env = os.environ.get('TARGET_RULES', '')
    target_rules = [r.strip() for r in target_rules_env.split(',') if r.strip()]

    findings = []

    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = urllib.parse.unquote_plus(record['s3']['object']['key'])

        try:
            response = s3.get_object(Bucket=bucket, Key=key)
            data = json.loads(response['Body'].read().decode('utf-8'))
            issues = data.get("issues", [])
            image_tag = data.get("imageTag", "unknown-tag")

            for issue in issues:
                rule = issue.get("rule", "")
                if rule in target_rules:
                    findings.append({
                        "rule": rule,
                        "message": issue.get("message", ""),
                        "file": issue.get("component", ""),
                        "line": issue.get("line", "?"),
                        "range": issue.get("textRange", {})
                    })

        except Exception as e:
            print(f"❌ Error reading object: {e}")

    if webhook_url:
        try:
            if findings:
                blocks = [
                    f":rotating_light: *SonarQube 최소정책 위반 발생 (총 {len(findings)}개)*",
                    f"🧷 *Image Tag:* `{image_tag}`\n"
                ]
                for idx, f in enumerate(findings, start=1):
                    start = f['range'].get('startLine', '?')
                    end = f['range'].get('endLine', '?')
                    blocks.append(
                        f"{idx}. {f['rule']}\n"
                        f"   • File: `{f['file']}` (Line: {f['line']})\n"
                        f"   • Range: {start} ~ {end}\n"
                        f"   • Message: {f['message']}\n"
                    )
                slack_payload = {"text": "\n".join(blocks)}
            else:
                slack_payload = {
                    "text": f"✅ SonarQube 최소정책 위반 없음\n🧷 *Image Tag:* `{image_tag}`"
                }

            res = http.request(
                "POST",
                webhook_url,
                body=json.dumps(slack_payload).encode("utf-8"),
                headers={'Content-Type': 'application/json'}
            )
            print("✅ Slack 알림 전송 완료")
        except Exception as e:
            print(f"❌ Slack 알림 실패: {e}")

    return {
        'statusCode': 200,
        'body': json.dumps({"slack_notified": True, "violations": len(findings)})
    }
